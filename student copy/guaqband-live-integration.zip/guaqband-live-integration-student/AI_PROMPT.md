# Student integration prompt

I am on my own branch of the class repository. The extracted kit is in `live_lab/`, which is my working folder, and I have attached my completed preprocessing/KNN notebook. Build a separate student pipeline here; do not modify the original repository-level `calibration_pipeline/`.

Integrate my four notebook functions into `calibration_pipeline/eflesh_calibration/knn.py`: `moving_average`, `feature`, `normalized_distances`, and `predict`. Reuse my implementations; do not replace them with a new classifier. If an implementation is wrong, explain the issue and make the smallest correction.

Keep the supplied serial reader, timestamp resampling, calibration flow, model saving/loading, and label stabilization. Keep the firmware pins, mux channels, serial packet format, and 115200 baud unchanged. Do not install scikit-learn or introduce a different algorithm. Do not run hardware commands until I supply the serial port.

Contracts:
- Four XYZ sensors = 12 channels at a 50 Hz target.
- Five-sample causal averaging: N×12 -> (N−4)×12, no padding or future samples.
- Features: 19×12 raw window + 12-value relaxed baseline -> 12 signed means followed by 12 RMS values.
- Distances: use the saved training means/scales for both training examples and query.
- KNN: k=3, majority vote; tied votes choose the nearest tied label, equal distances retain training order.

Run all commands from `live_lab/` so Python imports the student pipeline. Inspect the files, integrate my functions, and run `python check_integration.py` plus `python -m calibration_pipeline.eflesh_calibration --help`. Fix integration errors without altering the framework. Do not read or modify a personal calibration profile during these checks.

Then show the exact commands to list serial ports, calibrate my wearer/placement, and start live predictions. Explain the path from an incoming FRAME to the final label, identify where my four functions run, and tell me which checks passed and whether hardware was actually tested.
