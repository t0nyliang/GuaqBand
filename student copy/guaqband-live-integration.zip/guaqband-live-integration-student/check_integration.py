"""Offline smoke check for the student's four functions. No serial hardware or real profile is used."""
from pathlib import Path
import tempfile
import sys

import numpy as np
from calibration_pipeline.eflesh_calibration import knn
from calibration_pipeline.eflesh_calibration.app import LiveWindowResampler, LabelStabilizer
from calibration_pipeline.eflesh_calibration.sensor import SensorFrame, parse_sensor_frame

ROOT = Path(__file__).resolve().parent


def check_functions():
    values = np.arange(-6., 6.)
    raw = np.tile(values, (19, 1))
    filtered = knn.moving_average(raw)
    assert filtered.shape == (15, 12), 'moving_average must return (15, 12) for 19 raw rows'
    np.testing.assert_allclose(filtered, np.tile(values, (15, 1)))
    print('moving_average: PASS')

    features = knn.feature(raw, np.zeros(12))
    assert features.shape == (24,), 'feature must return 24 values'
    np.testing.assert_allclose(features, np.concatenate([values, np.abs(values)]))
    print('feature: PASS')

    examples = np.zeros((4, 24))
    examples[:, 0] = [1., 2., 3., 9.]
    model = dict(features=examples.tolist(), labels=['rest', 'fist', 'fist', 'spread'],
                 feature_mean=[0.] * 24, feature_scale=[1.] * 24, k=3)
    np.testing.assert_allclose(knn.normalized_distances(model, np.zeros(24)), [1., 2., 3., 9.])
    print('normalized_distances: PASS')
    assert knn.predict(model, np.zeros(24)) == 'fist', 'The nearest three must vote'
    print('predict: PASS')


def check_framework():
    packet = 'FRAME,0,0,' + ','.join(['1'] * 12)
    frame = parse_sensor_frame(packet)
    assert frame is not None and frame.values.shape == (12,)
    builder = LiveWindowResampler()
    window = None
    for index in range(25):
        window, reset = builder.add(SensorFrame(index, index * 20000, np.ones(12)))
        assert not reset
    assert window is not None and window.shape == (19, 12)
    stable = LabelStabilizer()
    assert stable.update('fist') == 'rest'
    assert stable.update('fist') == 'fist'
    print('Frame parsing, rolling windows, and label stabilization: PASS')


def check_synthetic_flow():
    with np.load(ROOT / 'data/gesture_trials.npz', allow_pickle=False) as data:
        signals = data['signals_ut'].copy()
        times = data['time_s'].copy()
        labels = data['labels'].tolist()
        splits = data['splits'].tolist()
    features = []
    for raw in signals:
        baseline = raw[times < 1.5].mean(axis=0)
        held = raw[(times >= 3.) & (times < 5.)][:19]
        result = knn.feature(held, baseline)
        assert result.shape == (24,) and np.isfinite(result).all()
        features.append(result)
    train = np.array([split == 'train' for split in splits])
    model = knn.make_model(np.array(features)[train], [label for label, keep in zip(labels, train) if keep])
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / 'test_profile.json'
        knn.save_model(model, path)
        restored = knn.load_model(path)
        count = 0
        for example, keep in zip(features, train):
            if not keep:
                assert knn.predict(restored, example) in knn.CLASSES
                count += 1
    print(f'SYNTHETIC feature → model → save/load → prediction flow: PASS ({count} queries)')
    print('This checks integration, not real-wearer accuracy. Hardware has not been tested.')


def main():
    try:
        check_functions()
        check_framework()
        check_synthetic_flow()
    except NotImplementedError as exc:
        print(f'INCOMPLETE: {exc}. Add your four notebook implementations to knn.py.')
        return 1
    except (AssertionError, ValueError, TypeError, IndexError) as exc:
        print(f'CHECK FAILED: {exc}')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
