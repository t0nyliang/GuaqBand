# Synthetic offline check data

40 generated seven-second recordings, 350 samples × 12 channels per trial, 50 Hz, µT units. There are four gesture labels and six training, two tuning, two test trials per label. Seed: 90393. Source: the preprocessing lab's synthetic dataset.

These are teaching signals with rest, motion, hold, release, noise and drift. They are not hardware measurements. The integration check uses these files only to verify that your functions connect to the supplied runtime. It does not validate performance on a wearer. Real calibration records fresh data from your hardware.
